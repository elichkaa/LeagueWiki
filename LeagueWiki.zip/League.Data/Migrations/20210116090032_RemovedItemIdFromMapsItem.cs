﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace League.Data.Migrations
{
    public partial class RemovedItemIdFromMapsItem : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
