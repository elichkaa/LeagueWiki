﻿namespace League.ConsoleApp.DTOs.Champions
{
    public class VarsDto
    {
        public string Link { get; set; }
        public double? Coeff { get; set; }
        public string Key { get; set; }
    }
}
